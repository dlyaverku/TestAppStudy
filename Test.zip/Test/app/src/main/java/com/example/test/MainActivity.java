package com.example.test;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Layout;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
Button button;
EditText user;
EditText mail;
EditText pass;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        button=findViewById(R.id.button_regist);
        user= findViewById(R.id.usename);
        mail=findViewById(R.id.email);
        pass=findViewById(R.id.pass);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(TextUtils.isEmpty(user.getText().toString()))
                {
                    Toast.makeText(MainActivity.this,"No empty field",Toast.LENGTH_SHORT).show();
                }
                if(TextUtils.isEmpty(mail.getText().toString()))
                {
                    Toast.makeText(MainActivity.this,"No empty field",Toast.LENGTH_SHORT).show();
                }

                if(TextUtils.isEmpty(pass.getText().toString()))
                {
                    Toast.makeText(MainActivity.this,"No empty field",Toast.LENGTH_SHORT).show();
                }
                else{ Intent intent=new Intent(MainActivity.this,NewEmpty.class);
                startActivity(intent);

                }
            }
        });
    }




}
